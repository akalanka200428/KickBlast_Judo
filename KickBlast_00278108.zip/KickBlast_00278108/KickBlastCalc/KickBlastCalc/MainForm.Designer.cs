﻿namespace KickBlastCalc
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.label1 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonViewAllReg = new System.Windows.Forms.Button();
            this.buttonInitiate = new System.Windows.Forms.Button();
            this.buttonFeeCalc = new System.Windows.Forms.Button();
            this.buttonPayment_History = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(353, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "ようこそ";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonExit.Location = new System.Drawing.Point(672, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 23);
            this.buttonExit.TabIndex = 25;
            this.buttonExit.Text = "Exit application";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonViewAllReg
            // 
            this.buttonViewAllReg.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonViewAllReg.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonViewAllReg.Location = new System.Drawing.Point(342, 277);
            this.buttonViewAllReg.Name = "buttonViewAllReg";
            this.buttonViewAllReg.Size = new System.Drawing.Size(150, 23);
            this.buttonViewAllReg.TabIndex = 27;
            this.buttonViewAllReg.Text = "View all registered athletes";
            this.buttonViewAllReg.UseVisualStyleBackColor = false;
            this.buttonViewAllReg.Click += new System.EventHandler(this.buttonViewAllReg_Click);
            // 
            // buttonInitiate
            // 
            this.buttonInitiate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttonInitiate.Location = new System.Drawing.Point(355, 248);
            this.buttonInitiate.Name = "buttonInitiate";
            this.buttonInitiate.Size = new System.Drawing.Size(116, 23);
            this.buttonInitiate.TabIndex = 28;
            this.buttonInitiate.Text = "Initiate an athlete";
            this.buttonInitiate.UseVisualStyleBackColor = false;
            this.buttonInitiate.Click += new System.EventHandler(this.buttonInitiate_Click);
            // 
            // buttonFeeCalc
            // 
            this.buttonFeeCalc.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttonFeeCalc.Location = new System.Drawing.Point(355, 104);
            this.buttonFeeCalc.Name = "buttonFeeCalc";
            this.buttonFeeCalc.Size = new System.Drawing.Size(116, 23);
            this.buttonFeeCalc.TabIndex = 29;
            this.buttonFeeCalc.Text = "Fee calculator";
            this.buttonFeeCalc.UseVisualStyleBackColor = false;
            this.buttonFeeCalc.Click += new System.EventHandler(this.buttonFeeCalc_Click);
            // 
            // buttonPayment_History
            // 
            this.buttonPayment_History.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonPayment_History.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonPayment_History.Location = new System.Drawing.Point(355, 133);
            this.buttonPayment_History.Name = "buttonPayment_History";
            this.buttonPayment_History.Size = new System.Drawing.Size(116, 23);
            this.buttonPayment_History.TabIndex = 32;
            this.buttonPayment_History.Text = "Payment history";
            this.buttonPayment_History.UseVisualStyleBackColor = false;
            this.buttonPayment_History.Click += new System.EventHandler(this.buttonPayment_History_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonPayment_History);
            this.Controls.Add(this.buttonFeeCalc);
            this.Controls.Add(this.buttonInitiate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonViewAllReg);
            this.Controls.Add(this.buttonExit);
            this.Name = "MainForm";
            this.Text = "KickBlast Judo - Welcome";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonViewAllReg;
        private System.Windows.Forms.Button buttonInitiate;
        private System.Windows.Forms.Button buttonFeeCalc;
        private System.Windows.Forms.Button buttonPayment_History;
    }
}