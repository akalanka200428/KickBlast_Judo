﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddNew_Click(object sender, EventArgs e)
        {

        }

        private void buttonFeeCalc_Click(object sender, EventArgs e)
        {
            monthly_calc newForm = new monthly_calc();
            newForm.Show();
            this.Close();
        }

        private void buttonInitiate_Click(object sender, EventArgs e)
        {
            add_athlete newForm = new add_athlete();
            newForm.Show();
            this.Close();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonViewAllReg_Click(object sender, EventArgs e)
        {
            View_Athletes newForm = new View_Athletes();
            newForm.Show();
            this.Close();
        }

        private void buttonPayment_History_Click(object sender, EventArgs e)
        {
            View_Payments newForm = new View_Payments();
            newForm.Show();
            this.Close();
        }
    }
}
