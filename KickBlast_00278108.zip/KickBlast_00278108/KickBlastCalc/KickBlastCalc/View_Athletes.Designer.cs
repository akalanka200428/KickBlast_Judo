﻿namespace KickBlastCalc
{
    partial class View_Athletes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewAthletes = new System.Windows.Forms.DataGridView();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAthletes)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAthletes
            // 
            this.dataGridViewAthletes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAthletes.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewAthletes.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewAthletes.Name = "dataGridViewAthletes";
            this.dataGridViewAthletes.Size = new System.Drawing.Size(800, 356);
            this.dataGridViewAthletes.TabIndex = 0;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonExit.Location = new System.Drawing.Point(672, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 23);
            this.buttonExit.TabIndex = 26;
            this.buttonExit.Text = "Exit application";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonMain.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMain.Location = new System.Drawing.Point(672, 362);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(116, 23);
            this.buttonMain.TabIndex = 28;
            this.buttonMain.Text = "Main menu";
            this.buttonMain.UseVisualStyleBackColor = false;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonEdit.Location = new System.Drawing.Point(12, 362);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(116, 23);
            this.buttonEdit.TabIndex = 29;
            this.buttonEdit.Text = "Edit existing athletes";
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // View_Athletes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.dataGridViewAthletes);
            this.Name = "View_Athletes";
            this.Text = "KickBlast Judo";
            this.Load += new System.EventHandler(this.View_Athletes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAthletes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAthletes;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Button buttonEdit;
    }
}