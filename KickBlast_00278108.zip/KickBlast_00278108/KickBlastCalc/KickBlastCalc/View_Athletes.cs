﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class View_Athletes : Form
    {
        public View_Athletes()
        {
            InitializeComponent();
        }

        private void View_Athletes_Load(object sender, EventArgs e)
        {
            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM EnrolledAthletes";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridViewAthletes.DataSource = table;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading athletes: " + ex.Message);
                }
            }
        }

private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonFeeCalc_Click(object sender, EventArgs e)
        {
            monthly_calc newForm = new monthly_calc();
            newForm.Show();
            this.Close();
        }
        
        private void buttonAdd_New_Click(object sender, EventArgs e)
        {
            add_athlete newForm = new add_athlete();
            newForm.Show();
            this.Close();
        }

        private void button_Manage_Click(object sender, EventArgs e)
        {
            manage_Athletes newform1 = new manage_Athletes();
            newform1.Show();
            this.Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Close();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            manage_Athletes manageform = new manage_Athletes();
            manageform.Show();
            this.Close();
        }
    }
}
