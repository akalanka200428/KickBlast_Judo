﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class add_athlete : Form
    {
        public add_athlete()
        {
            InitializeComponent();
        }

        private void add_athlete_Load(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonAdd_New_Click(object sender, EventArgs e)
        {
            string name = textboxName.Text.Trim();
            int age = (int)numericAge.Value;
            decimal weight = numericWeight.Value;

            string gender = "";
            if (radioMale.Checked)
                gender = "Male";
            else if (radioFem.Checked)
                gender = "Female";
            else
            {
                MessageBox.Show("Please specify gender.");
                return;
            }

            string trainingPlan = comboTrainingPlan.Text;
            string weightCategory = comboWeightCategory.Text;
            string contactNumber = textboxContact.Text.Trim();
            string emergencyContact = textboxContact2.Text.Trim();
            string emailpersonal = textBoxEmail.Text.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(trainingPlan) ||
                string.IsNullOrEmpty(weightCategory) || string.IsNullOrEmpty(contactNumber))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";
            string query = "INSERT INTO EnrolledAthletes (Name, Age, Gender, TrainingPlan, Weight, WeightCategory, ContactNumber, EmergencyContact, Email) " +
                           "VALUES (@n, @a, @g, @t, @w, @wc, @c, @ec, @ep)";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@a", age);
                    cmd.Parameters.AddWithValue("@g", gender);
                    cmd.Parameters.AddWithValue("@t", trainingPlan);
                    cmd.Parameters.AddWithValue("@w", weight);
                    cmd.Parameters.AddWithValue("@wc", weightCategory);
                    cmd.Parameters.AddWithValue("@c", contactNumber);
                    cmd.Parameters.AddWithValue("@ec", emergencyContact);
                    cmd.Parameters.AddWithValue("ep", emailpersonal);
                    

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Athlete initiation successful!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void numericWeight_ValueChanged(object sender, EventArgs e)
        {
            decimal weight = numericWeight.Value;

            if (weight < 60)
                comboWeightCategory.Text = "Flyweight";
            else if (weight >= 60 && weight < 70)
                comboWeightCategory.Text = "Lightweight";
            else if (weight >= 70 && weight < 80)
                comboWeightCategory.Text = "Light–Middleweight";
            else if (weight >= 80 && weight < 90)
                comboWeightCategory.Text = "Middleweight";
            else if (weight >= 90 && weight < 100)
                comboWeightCategory.Text = "Light–Heavyweight";
            else
                comboWeightCategory.Text = "Heavyweight";
        }

        private void buttonMenu_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Close();
        }
    }
}
