﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class manage_Athletes : Form
    {
        public manage_Athletes()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            View_Athletes newform = new View_Athletes();
            newform.Show();
            this.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            int athlete_id = Convert.ToInt32(textBoxAthlete_ID.Text);

            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";
            string query = "DELETE FROM EnrolledAthletes WHERE Athlete_ID=@id";

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", athlete_id);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                            MessageBox.Show("Athlete record deleted!");
                        else
                            MessageBox.Show("No record found with this Athlete ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void buttonUpdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True"))
                {
                    con.Open();

                    string query = @"UPDATE EnrolledAthletes 
                             SET Name = @Name, 
                                 Age = @Age, 
                                 Gender = @Gender, 
                                 TrainingPlan = @TrainingPlan, 
                                 Weight = @Weight, 
                                 WeightCategory = @WeightCategory, 
                                 ContactNumber = @ContactNumber, 
                                 EmergencyContact = @EmergencyContact, 
                                 Email = @Email
                             WHERE Athlete_ID = @Athlete_ID";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Athlete_ID", int.Parse(textBoxAthlete_ID.Text));
                        cmd.Parameters.AddWithValue("@Name", textboxName.Text);
                        cmd.Parameters.AddWithValue("@Age", numericAge.Value);

                        string gender = radioMale.Checked ? "Male" : "Female";
                        cmd.Parameters.AddWithValue("@Gender", gender);

                        cmd.Parameters.AddWithValue("@TrainingPlan", comboTrainingPlan.SelectedItem?.ToString() ?? "");
                        cmd.Parameters.AddWithValue("@Weight", numericWeight.Value);
                        cmd.Parameters.AddWithValue("@WeightCategory", comboWeightCategory.SelectedItem?.ToString() ?? "");
                        cmd.Parameters.AddWithValue("@ContactNumber", textboxContact.Text);
                        cmd.Parameters.AddWithValue("@EmergencyContact", textboxContact2.Text);
                        cmd.Parameters.AddWithValue("@Email", textBoxEmail.Text);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                            MessageBox.Show("Athlete updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("No athlete found with that ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating athlete: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            int athleteId;
            if (!int.TryParse(textBoxAthlete_ID.Text, out athleteId))
            {
                MessageBox.Show("Enter a valid Athlete ID.");
                return;
            }
            // establish connection
            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";
            string query = "SELECT * FROM EnrolledAthletes WHERE Athlete_ID = @id";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", athleteId);
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        textboxName.Text = reader["Name"].ToString();

                        comboTrainingPlan.Text = reader["TrainingPlan"].ToString();
                        numericWeight.Value = Convert.ToDecimal(reader["Weight"]);
                        comboWeightCategory.Text = reader["WeightCategory"].ToString();
                        textBoxEmail.Text = reader["Email"].ToString();
                        numericAge.Value = Convert.ToDecimal(reader["Age"]);
                        textboxContact.Text = reader["ContactNumber"].ToString();
                        textboxContact2.Text = reader["EmergencyContact"].ToString();
                        
                        string gender = reader["Gender"].ToString();

                        // Assign value to radio buttons
                        if (gender == "Male")
                        {
                            radioMale.Checked = true;
                        }
                        else if (gender == "Female")
                        {
                            radioFem.Checked = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No athlete found with that ID.");
                    }
                }
            }
        }
    }
}