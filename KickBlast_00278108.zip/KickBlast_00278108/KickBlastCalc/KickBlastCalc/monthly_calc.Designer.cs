﻿namespace KickBlastCalc
{
    partial class monthly_calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(monthly_calc));
            this.label1 = new System.Windows.Forms.Label();
            this.textboxName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDownWeight = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCompetitions = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCoaching = new System.Windows.Forms.NumericUpDown();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxWCategory = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxTrainPlan = new System.Windows.Forms.ComboBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.calc_Background = new System.Windows.Forms.PictureBox();
            this.buttonBack = new System.Windows.Forms.Button();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.label_ID = new System.Windows.Forms.Label();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCompetitions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCoaching)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calc_Background)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Athlete name:";
            // 
            // textboxName
            // 
            this.textboxName.Location = new System.Drawing.Point(216, 81);
            this.textboxName.Name = "textboxName";
            this.textboxName.Size = new System.Drawing.Size(269, 20);
            this.textboxName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Training plan:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox1.Controls.Add(this.buttonSearch);
            this.groupBox1.Controls.Add(this.textBox_ID);
            this.groupBox1.Controls.Add(this.label_ID);
            this.groupBox1.Controls.Add(this.buttonBack);
            this.groupBox1.Controls.Add(this.textboxName);
            this.groupBox1.Controls.Add(this.numericUpDownWeight);
            this.groupBox1.Controls.Add(this.numericUpDownCompetitions);
            this.groupBox1.Controls.Add(this.numericUpDownCoaching);
            this.groupBox1.Controls.Add(this.buttonCalc);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBoxWCategory);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.comboBoxTrainPlan);
            this.groupBox1.Location = new System.Drawing.Point(50, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(512, 406);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Monthly fee calculation";
            // 
            // numericUpDownWeight
            // 
            this.numericUpDownWeight.Location = new System.Drawing.Point(216, 167);
            this.numericUpDownWeight.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownWeight.Name = "numericUpDownWeight";
            this.numericUpDownWeight.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownWeight.TabIndex = 18;
            // 
            // numericUpDownCompetitions
            // 
            this.numericUpDownCompetitions.Location = new System.Drawing.Point(216, 259);
            this.numericUpDownCompetitions.Name = "numericUpDownCompetitions";
            this.numericUpDownCompetitions.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownCompetitions.TabIndex = 17;
            // 
            // numericUpDownCoaching
            // 
            this.numericUpDownCoaching.Location = new System.Drawing.Point(216, 311);
            this.numericUpDownCoaching.Name = "numericUpDownCoaching";
            this.numericUpDownCoaching.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownCoaching.TabIndex = 16;
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(265, 367);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(100, 23);
            this.buttonCalc.TabIndex = 14;
            this.buttonCalc.Text = "Calculate cost";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.calc_BTN_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 326);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "(5 max per week)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Private coaching hours:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "(this month)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "No. of competetions entered:";
            // 
            // comboBoxWCategory
            // 
            this.comboBoxWCategory.FormattingEnabled = true;
            this.comboBoxWCategory.Items.AddRange(new object[] {
            "Flyweight",
            "Lightweight",
            "Light–Middleweight",
            "Middleweight",
            "Light–Heavyweight",
            "Heavyweight"});
            this.comboBoxWCategory.Location = new System.Drawing.Point(216, 210);
            this.comboBoxWCategory.Name = "comboBoxWCategory";
            this.comboBoxWCategory.Size = new System.Drawing.Size(187, 21);
            this.comboBoxWCategory.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Competetion weight category:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Current weight (kg):";
            // 
            // comboBoxTrainPlan
            // 
            this.comboBoxTrainPlan.FormattingEnabled = true;
            this.comboBoxTrainPlan.Items.AddRange(new object[] {
            "Beginner",
            "Intermediate",
            "Elite"});
            this.comboBoxTrainPlan.Location = new System.Drawing.Point(216, 122);
            this.comboBoxTrainPlan.Name = "comboBoxTrainPlan";
            this.comboBoxTrainPlan.Size = new System.Drawing.Size(149, 21);
            this.comboBoxTrainPlan.TabIndex = 0;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonExit.Location = new System.Drawing.Point(663, 452);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 23);
            this.buttonExit.TabIndex = 18;
            this.buttonExit.Text = "Exit application";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.exit_BTN_Click);
            // 
            // calc_Background
            // 
            this.calc_Background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calc_Background.Image = ((System.Drawing.Image)(resources.GetObject("calc_Background.Image")));
            this.calc_Background.Location = new System.Drawing.Point(0, 0);
            this.calc_Background.Name = "calc_Background";
            this.calc_Background.Size = new System.Drawing.Size(800, 487);
            this.calc_Background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.calc_Background.TabIndex = 19;
            this.calc_Background.TabStop = false;
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(436, 367);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(60, 23);
            this.buttonBack.TabIndex = 19;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // textBox_ID
            // 
            this.textBox_ID.Location = new System.Drawing.Point(216, 36);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(149, 20);
            this.textBox_ID.TabIndex = 21;
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.Location = new System.Drawing.Point(44, 39);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(57, 13);
            this.label_ID.TabIndex = 20;
            this.label_ID.Text = "Athlete ID:";
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(389, 33);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 23);
            this.buttonSearch.TabIndex = 22;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // monthly_calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 487);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.calc_Background);
            this.Name = "monthly_calc";
            this.Text = "KickBlast Judo";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCompetitions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCoaching)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calc_Background)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textboxName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxTrainPlan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxWCategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.PictureBox calc_Background;
        private System.Windows.Forms.NumericUpDown numericUpDownCoaching;
        private System.Windows.Forms.NumericUpDown numericUpDownCompetitions;
        private System.Windows.Forms.NumericUpDown numericUpDownWeight;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Button buttonSearch;
    }
}

