﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class monthly_calc : Form
    {
        public monthly_calc()
        {
            InitializeComponent();
        }

        private void exit_BTN_Click(object sender, EventArgs e)
        {
                Application.Exit();
        }

        private void calc_BTN_Click(object sender, EventArgs e)
        {
            // Validate Athlete ID input
            if (!int.TryParse(textBox_ID.Text.Trim(), out int a_id))
            {
                MessageBox.Show("Please enter a valid Athlete ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if Athlete exists in DB
            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";
            string checkQuery = "SELECT COUNT(*) FROM EnrolledAthletes WHERE Athlete_ID = @id";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(checkQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@id", a_id);
                    conn.Open();

                    int count = (int)cmd.ExecuteScalar();

                    if (count == 0)
                    {
                        MessageBox.Show("No athlete found with this ID. Please register the athlete first.",
                                        "Athlete Not Found",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            // Proceed with inputs if Athlete exists
            string name = textboxName.Text.Trim();
            string plan = comboBoxTrainPlan.SelectedItem?.ToString();
            decimal weight = numericUpDownWeight.Value;
            string category = comboBoxWCategory.SelectedItem?.ToString();
            int competitions = (int)numericUpDownCompetitions.Value;
            int coachingHours = (int)numericUpDownCoaching.Value;

            // Validation checks
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(plan) || string.IsNullOrEmpty(category))
            {
                MessageBox.Show("Please fill all given fields.", "Missing Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (coachingHours > 20)
            {
                MessageBox.Show("Maximum private coaching per month is 20 (5 hours a week).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (plan == "Beginner" && competitions > 0)
            {
                MessageBox.Show("Only Intermediate and Elite athletes can enter competitions.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Costs
            decimal planCost = 0;
            decimal compCost = competitions * 220.00m;
            decimal coachingCost = coachingHours * 90.50m;

            switch (plan)
            {
                case "Beginner":
                    planCost = 250.00m;
                    break;
                case "Intermediate":
                    planCost = 300.00m;
                    break;
                case "Elite":
                    planCost = 350.00m;
                    break;
            }

            // Multiply weekly cost by 4 to get monthly cost
            // since KickBlast Judo assumes a month contains 4 weeks
            planCost *= 4;

            decimal totalCost = planCost + compCost + coachingCost;

            // Weight categories
            Dictionary<string, (decimal Min, decimal Max)> weightRanges = new Dictionary<string, (decimal, decimal)>
            {
               { "Flyweight", (0, 66) },
               { "Lightweight", (67, 73) },
               { "Light–Middleweight", (74, 81) },
               { "Middleweight", (82, 90) },
               { "Light–Heavyweight", (91, 100) },
               { "Heavyweight", (101, 9999) }
            };

            string weightStatus;

            if (weightRanges.TryGetValue(category, out var range))
            {
                if (weight < range.Min)
                    weightStatus = $"Invalid, update weight category next month - below {category} range ({range.Min}–{range.Max} kg)";
                else if (weight > range.Max)
                    weightStatus = $"Invalid, update weight category next month - above {category} range ({range.Min}–{range.Max} kg)";
                else
                    weightStatus = $"Within {category} range ({range.Min}–{range.Max} kg)";
            }
            else
            {
                MessageBox.Show("Invalid weight category.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Show results in second form
            monthly_calc_results resultForm = new monthly_calc_results();
            resultForm.A_ID = a_id;
            resultForm.AthleteName = name;
            resultForm.PlanCost = planCost;
            resultForm.CompetitionCost = compCost;
            resultForm.CoachingCost = coachingCost;
            resultForm.TotalCost = totalCost;
            resultForm.WeightStatus = weightStatus;

            resultForm.Show();
            this.Hide();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            MainForm newform1 = new MainForm();
            newform1.Show();
            this.Close();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            int athleteId;
            if (!int.TryParse(textBox_ID.Text, out athleteId))
            {
                MessageBox.Show("Enter a valid Athlete ID.");
                return;
            }
            // establish connection
            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";
            string query = "SELECT * FROM EnrolledAthletes WHERE Athlete_ID = @id";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", athleteId);
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        textboxName.Text = reader["Name"].ToString();

                        comboBoxTrainPlan.Text = reader["TrainingPlan"].ToString();
                        numericUpDownWeight.Value = Convert.ToDecimal(reader["Weight"]);
                        comboBoxWCategory.Text = reader["WeightCategory"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No athlete found with that ID.");
                    }
                }
            }
        }

        //name = name of the athlete
        //planCost = weekly cost of training plan
        //competetionCost = total cost for competetions
        //coachingCost = fees for private coaching
        //totalCost = the addition of all costs
        //weightStatus = the comment on weight of the athlete
        //category = weight category
        //categoryLimit = weight limit in numbers
    }
}
