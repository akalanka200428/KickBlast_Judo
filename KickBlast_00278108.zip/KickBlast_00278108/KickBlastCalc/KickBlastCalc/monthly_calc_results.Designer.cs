﻿namespace KickBlastCalc
{
    partial class monthly_calc_results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(monthly_calc_results));
            this.calc_Background = new System.Windows.Forms.PictureBox();
            this.buttonComplete = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelWeightStat = new System.Windows.Forms.Label();
            this.labelTotalCost = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelCoachingCost = new System.Windows.Forms.Label();
            this.labelCompCost = new System.Windows.Forms.Label();
            this.labelPlanCost = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.buttonMain = new System.Windows.Forms.Button();
            this.buttonPayment_History = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonRefill_Form = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.calc_Background)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // calc_Background
            // 
            this.calc_Background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calc_Background.Image = ((System.Drawing.Image)(resources.GetObject("calc_Background.Image")));
            this.calc_Background.Location = new System.Drawing.Point(0, 0);
            this.calc_Background.Name = "calc_Background";
            this.calc_Background.Size = new System.Drawing.Size(800, 450);
            this.calc_Background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.calc_Background.TabIndex = 20;
            this.calc_Background.TabStop = false;
            // 
            // buttonComplete
            // 
            this.buttonComplete.Location = new System.Drawing.Point(126, 340);
            this.buttonComplete.Name = "buttonComplete";
            this.buttonComplete.Size = new System.Drawing.Size(84, 23);
            this.buttonComplete.TabIndex = 14;
            this.buttonComplete.Text = "Payment done";
            this.buttonComplete.UseVisualStyleBackColor = true;
            this.buttonComplete.Click += new System.EventHandler(this.buttonComplete_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 270);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Weight comparison:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Itemized monthly cost:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Athlete name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Competetion fees:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Training plan cost:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonRefill_Form);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label_ID);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.labelWeightStat);
            this.groupBox1.Controls.Add(this.labelTotalCost);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.labelCoachingCost);
            this.groupBox1.Controls.Add(this.labelCompCost);
            this.groupBox1.Controls.Add(this.labelPlanCost);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.labelName);
            this.groupBox1.Controls.Add(this.buttonComplete);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(36, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(505, 379);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Monthly fee calculation results";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Athlete ID:";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.Location = new System.Drawing.Point(213, 37);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(59, 13);
            this.label_ID.TabIndex = 28;
            this.label_ID.Text = "[display ID]";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(213, 213);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "LKR";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(213, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "LKR";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(213, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "LKR";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(213, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "LKR";
            // 
            // labelWeightStat
            // 
            this.labelWeightStat.AutoSize = true;
            this.labelWeightStat.Location = new System.Drawing.Point(44, 293);
            this.labelWeightStat.Name = "labelWeightStat";
            this.labelWeightStat.Size = new System.Drawing.Size(67, 13);
            this.labelWeightStat.TabIndex = 23;
            this.labelWeightStat.Text = "[comparison]";
            // 
            // labelTotalCost
            // 
            this.labelTotalCost.AutoSize = true;
            this.labelTotalCost.Location = new System.Drawing.Point(260, 213);
            this.labelTotalCost.Name = "labelTotalCost";
            this.labelTotalCost.Size = new System.Drawing.Size(28, 13);
            this.labelTotalCost.TabIndex = 22;
            this.labelTotalCost.Text = "0.00";
            this.labelTotalCost.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(44, 213);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "Total cost:";
            // 
            // labelCoachingCost
            // 
            this.labelCoachingCost.AutoSize = true;
            this.labelCoachingCost.Location = new System.Drawing.Point(260, 185);
            this.labelCoachingCost.Name = "labelCoachingCost";
            this.labelCoachingCost.Size = new System.Drawing.Size(28, 13);
            this.labelCoachingCost.TabIndex = 20;
            this.labelCoachingCost.Text = "0.00";
            // 
            // labelCompCost
            // 
            this.labelCompCost.AutoSize = true;
            this.labelCompCost.Location = new System.Drawing.Point(260, 161);
            this.labelCompCost.Name = "labelCompCost";
            this.labelCompCost.Size = new System.Drawing.Size(28, 13);
            this.labelCompCost.TabIndex = 19;
            this.labelCompCost.Text = "0.00";
            // 
            // labelPlanCost
            // 
            this.labelPlanCost.AutoSize = true;
            this.labelPlanCost.Location = new System.Drawing.Point(260, 136);
            this.labelPlanCost.Name = "labelPlanCost";
            this.labelPlanCost.Size = new System.Drawing.Size(28, 13);
            this.labelPlanCost.TabIndex = 18;
            this.labelPlanCost.Text = "0.00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(56, 184);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Private coaching costs:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(213, 60);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(74, 13);
            this.labelName.TabIndex = 16;
            this.labelName.Text = "[display name]";
            // 
            // buttonMain
            // 
            this.buttonMain.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonMain.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMain.Location = new System.Drawing.Point(440, 413);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(116, 23);
            this.buttonMain.TabIndex = 30;
            this.buttonMain.Text = "Main menu";
            this.buttonMain.UseVisualStyleBackColor = false;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // buttonPayment_History
            // 
            this.buttonPayment_History.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonPayment_History.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonPayment_History.Location = new System.Drawing.Point(36, 415);
            this.buttonPayment_History.Name = "buttonPayment_History";
            this.buttonPayment_History.Size = new System.Drawing.Size(116, 23);
            this.buttonPayment_History.TabIndex = 31;
            this.buttonPayment_History.Text = "Payment history";
            this.buttonPayment_History.UseVisualStyleBackColor = false;
            this.buttonPayment_History.Click += new System.EventHandler(this.buttonPayment_History_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonExit.Location = new System.Drawing.Point(672, 413);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 23);
            this.buttonExit.TabIndex = 32;
            this.buttonExit.Text = "Exit application";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonRefill_Form
            // 
            this.buttonRefill_Form.Location = new System.Drawing.Point(287, 340);
            this.buttonRefill_Form.Name = "buttonRefill_Form";
            this.buttonRefill_Form.Size = new System.Drawing.Size(75, 23);
            this.buttonRefill_Form.TabIndex = 31;
            this.buttonRefill_Form.Text = "Refill form";
            this.buttonRefill_Form.UseVisualStyleBackColor = true;
            this.buttonRefill_Form.Click += new System.EventHandler(this.buttonRefill_Form_Click);
            // 
            // monthly_calc_results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonPayment_History);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.calc_Background);
            this.Name = "monthly_calc_results";
            this.Text = "KickBlast Judo";
            ((System.ComponentModel.ISupportInitialize)(this.calc_Background)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox calc_Background;
        private System.Windows.Forms.Button buttonComplete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelCoachingCost;
        private System.Windows.Forms.Label labelCompCost;
        private System.Windows.Forms.Label labelPlanCost;
        private System.Windows.Forms.Label labelWeightStat;
        private System.Windows.Forms.Label labelTotalCost;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Button buttonPayment_History;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonRefill_Form;
    }
}