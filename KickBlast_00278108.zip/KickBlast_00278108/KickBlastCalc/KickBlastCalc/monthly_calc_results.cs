﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlastCalc
{
    public partial class monthly_calc_results : Form
    {

        // Public properties to receive data
        public int A_ID { get; set; }
        public string AthleteName { get; set; }
        public decimal PlanCost { get; set; }
        public decimal CompetitionCost { get; set; }
        public decimal CoachingCost { get; set; }
        public decimal TotalCost { get; set; }
        public string WeightStatus { get; set; }

        public monthly_calc_results()
        {
            InitializeComponent();
            this.Load += monthly_calc_results_Load;
        }

        private void monthly_calc_results_Load(object sender, EventArgs e)
        {
            label_ID.Text = A_ID.ToString();
            labelName.Text = AthleteName;
            labelPlanCost.Text = PlanCost.ToString();
            labelCompCost.Text = CompetitionCost.ToString();
            labelCoachingCost.Text = CoachingCost.ToString();
            labelTotalCost.Text = TotalCost.ToString();
            labelWeightStat.Text = WeightStatus;
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void buttonComplete_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(AthleteName) || TotalCost <= 0)
                    {
                        MessageBox.Show("Please calculate the fee before saving.");
                        return;
                    }

                    string connString = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True"; ;

                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        string query = "INSERT INTO Payments (Athlete_ID, Name, Base_Cost, Comp_Fees, PCoach_Cost, Total_Cost, Date) " +
                                       "VALUES (@Athlete_ID, @Name, @Base_Cost, @Comp_Fees, @PCoach_Cost, @Total_Cost, @Date)";

                        SqlCommand cmd = new SqlCommand(query, conn);

                        cmd.Parameters.AddWithValue("@Athlete_ID", A_ID);
                        cmd.Parameters.AddWithValue("@Name", AthleteName);
                        cmd.Parameters.AddWithValue("@Base_Cost", PlanCost);
                        cmd.Parameters.AddWithValue("@Comp_Fees", CompetitionCost);
                        cmd.Parameters.AddWithValue("@PCoach_Cost", CoachingCost);
                        cmd.Parameters.AddWithValue("@Total_Cost", TotalCost);

                        DateTime date = DateTime.Now.Date;
                        cmd.Parameters.AddWithValue("Date", date);

                        conn.Open();
                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                            MessageBox.Show("Payment recorded successfully!");
                        else
                            MessageBox.Show("No record was inserted. Refill your data.");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unexpected error: " + ex.Message);
                }
            }
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Close();
        }

        private void buttonPayment_History_Click(object sender, EventArgs e)
        {
            View_Payments view_Payments = new View_Payments(); 
            view_Payments.Show();
            this.Close();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonRefill_Form_Click(object sender, EventArgs e)
        {
            monthly_calc newForm = new monthly_calc();
            newForm.Show();
            this.Close();
        }
    }
}
