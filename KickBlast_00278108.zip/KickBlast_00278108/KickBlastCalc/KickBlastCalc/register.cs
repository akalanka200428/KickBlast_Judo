﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KickBlastCalc
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            // get the values from the specific textboxes
            string username = textboxUsername.Text.Trim();
            string name = textBoxFullname.Text.Trim();
            string password = textboxPassword.Text.Trim();
            string confirm = textboxConfirm.Text.Trim();
            string email = textboxEmail.Text.Trim();

            // Basic validation
            if (username == "" || name == "" || password == "" || confirm == "" || email == "")
            {
                MessageBox.Show("Fill all given fields.");
                return;
            }

            if (password != confirm)
            {
                MessageBox.Show("Make sure your passwords match.");
                return;
            }
            // establish connection
            string connStr = @"Data Source=MASTERCHIEF2004\SQLEXPRESS;Initial Catalog=KickBlast_Judo;Integrated Security=True";

            string query = "INSERT INTO Members ([Name], Username, Password, Email) VALUES (@n, @u, @p, @e)";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@p", password);
                    cmd.Parameters.AddWithValue("@e", email);

            // Finalizing by checking
                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registration successful!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login newForm = new Login();
            newForm.Show();
            this.Hide();
        }
    }
}
